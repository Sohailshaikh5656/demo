import 'dart:convert';

class Student{

    int?id;
    String firstname;
    String lastname;
    String email;
    String password;
    String country;

    Student({
      this.id,
      required this.firstname,
      required this.lastname,
      required this.email,
      required this.password,
      required this.country
  });


    Map<String,dynamic> toMap(){
      return{
        'firstname':firstname,
        'lastname':lastname,
        'email':email,
        'password':password,
        'country':country,
      };
    }

    factory Student.fromJson(Map<String, dynamic> json){
      return Student(
        id : json['id'] != null? int.tryParse(json['id'].toString()) : null,
        firstname: json['firstname'],
        lastname: json['lastname'],
        email: json['email'],
        password: json['password'],
        country: json['country'],
      );
    }
}