import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class wheatherController{
  
    static Future<Map<String, dynamic>> getWheatherData(String city) async {
      final url = Uri.parse(
          "https://open-weather13.p.rapidapi.com/city/$city/EN?units=metric");
      try {
        var response = await http.get(
            url,
            headers: {
              "x-rapidapi-key": "6cb93a27b5mshd5a9b43d8bbb5a0p17c515jsn505725ea46d0",
              "x-rapidapi-host": "open-weather13.p.rapidapi.com",
            }
        );

        print("\nStatus-Code : ${response.statusCode}");
        print("\nBody - Content : ${response.body}");
        if (response.statusCode == 200) {
          return jsonDecode(response.body);
        } else {
          print("Error in Fetching data : ${response.statusCode}");
          return {
            "error": "Failed to fetch data",
            "statusCode": response.statusCode
          };
        }
      }
      catch (error) {
        print("Failed to get data : ${error}");
        return {};
      }
    }
  }