import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:api_crud_tst/model/Student.dart';
import 'package:http/http.dart' as http;

class StudentController{
  static Future<void> createNewStudent(Student s) async{

    final url = Uri.parse("http://localhost/flutter_api/insert.php");
    try{
      var response = await http.post(url, body: s.toMap(), headers: {"content-type":"application/x-www-form-urlencoded"});
      var responseData = jsonDecode(response.body);
      if(responseData["success"]){
        print("Data Inserted Successfully !");

      }
      else{

        print("Failed to Insert Data");
      }
    }catch(errro){
      print("Somethiong Went Wrong !");
    }
  }

  static Future<List<Student>> getAllStudents() async{
    final url = Uri.parse("http://localhost/flutter_api/read.php");
    try{
      var response = await http.get(url);
      print("status Code : ${response.statusCode}");
      print("Body Response : ${response.body}");
      if(response.statusCode==200){
        List data = jsonDecode(response.body);
        return data.map((json)=>Student.fromJson(json)).toList();
      }
      else{
        throw Exception("Error Occur While Fetching Records : ${response.statusCode}");
      }
    }catch(error){
      print("Something went Wrong !");
      return [];
    }
  }

  static Future<void> deleteRecord(int id) async{
    final url = Uri.parse("http://localhost/flutter_api/delete.php");
    try{
      var response = await http.post(url, body:{'id':id.toString()} );
      if(response.statusCode == 200){
        print("Record Deleted Successfully !");
      }else{
        print("Error in Deleting Record  !");
      }
    }catch(error){
      print("Something went Wrong !");
    }
  }


}