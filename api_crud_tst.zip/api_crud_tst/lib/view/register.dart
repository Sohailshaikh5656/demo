import 'package:api_crud_tst/controller/studentController.dart';
import 'package:api_crud_tst/model/Student.dart';
import 'package:flutter/material.dart';

class Register extends StatefulWidget{
  @override
  _RegisterState createState() => _RegisterState();
}
class _RegisterState extends State<Register>{
String?selectedCountry;

TextEditingController firstname = TextEditingController();
TextEditingController lastname = TextEditingController();
TextEditingController email = TextEditingController();
TextEditingController password = TextEditingController();
TextEditingController country = TextEditingController();
void Trigger(){
  country.text = selectedCountry!;
  Student s = Student(firstname: firstname.text, lastname: lastname.text, email: email.text, password: password.text, country: country.text);
  StudentController.createNewStudent(s);

  firstname.text="";
  lastname.text="";
  email.text="";
  password.text="";
  country.text="";
  selectedCountry = "Select a Country";
}
  @override
  Widget build(BuildContext){
    return Scaffold(
      backgroundColor: Colors.white54,
      appBar: AppBar(
        leading: IconButton(onPressed: (){
          Navigator.pop(context);
        }, icon: Icon(Icons.arrow_back)),
        title:Text("Student Management System",style: TextStyle(fontSize: 20, fontFamily: 'Roboto', fontWeight: FontWeight.bold, color:Colors.amberAccent),),
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Container(
            margin: EdgeInsets.all(16),
            height: 700,
            width: 400,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(9),
              color: Colors.amberAccent,
            ),
            child: Center(
              child: Column(
                children: [
                  SizedBox(height: 30,),
                  Container(
                    height: 60,
                    width: 350,
                    child: Center(
                      child: Text("Student Register", style: TextStyle(fontSize: 36, fontWeight: FontWeight.bold, fontFamily: 'Roboto', color: Colors.white),),

                    ),
                  ),



                  SizedBox(height: 15,),
                  Container(
                    height: 60,
                    width: 350,
                    child: Center(
                      child: TextFormField(
                        controller: firstname,
                        decoration: InputDecoration(
                            fillColor: Colors.lightGreenAccent,
                            filled: true,
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(5),
                            ),
                            hintText: "Enter First Name"
                        ),
                      ),
                    ),
                  ),

                  //LastName
                  SizedBox(height: 15,),
                  Container(
                    height: 60,
                    width: 350,
                    child: Center(
                      child: TextFormField(
                        controller: lastname,
                        decoration: InputDecoration(
                            fillColor: Colors.lightGreenAccent,
                            filled: true,
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(5),
                            ),
                            hintText: "Enter Last Name"
                        ),
                      ),
                    ),
                  ),

                  //Email
                  SizedBox(height: 15,),
                  Container(
                    height: 60,
                    width: 350,
                    child: Center(
                      child: TextFormField(
                        controller: email,
                        decoration: InputDecoration(
                            fillColor: Colors.lightGreenAccent,
                            filled: true,
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(5),
                            ),
                            hintText: "Enter Email"
                        ),
                      ),
                    ),
                  ),

                  //Password

                  SizedBox(height: 15,),
                  Container(
                    height: 60,
                    width: 350,
                    child: Center(
                      child: TextFormField(
                        controller: password,
                        decoration: InputDecoration(
                            fillColor: Colors.lightGreenAccent,
                            filled: true,
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(5),
                            ),
                            hintText: "Enter Password"
                        ),
                      ),
                    ),
                  ),

                  //Country
                  SizedBox(height: 15,),
                  Container(
                    height: 60,
                    width: 350,
                    child: Center(
                      child: DropdownButton(
                      isExpanded: true,
                      dropdownColor: Colors.lightBlueAccent,
                      value: selectedCountry,
                      items: [
                        DropdownMenuItem(value : "India", child: Text("India"),),
                        DropdownMenuItem(value:"Pakistan", child: Text("Pakistan"),),
                        DropdownMenuItem(value:"USA", child: Text("USA"),),
                        DropdownMenuItem(value:"Nepal", child: Text("Nepal"),),
                      ], onChanged: (value){
                        setState(() {
                          selectedCountry = value;
                        });
                      }, hint: Text("Select Country"),),
                    ),
                  ),

                  SizedBox(height: 30,),
                  Container(
                    height: 60,
                    width: 350,
                    child: Center(
                        child : ElevatedButton(onPressed: (){Trigger();}, child: Text("ADD STUDENT",style: TextStyle(fontSize: 23, color: Colors.black),))
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}