import 'package:flutter/material.dart';
import 'package:api_crud_tst/controller/wheatherController.dart';

class Weather extends StatefulWidget {
  @override
  _WeatherState createState() => _WeatherState();
}

class _WeatherState extends State<Weather> {
  TextEditingController city = TextEditingController();
  String cityname = "London"; // Default city name
  late Future<Map<String, dynamic>> weatherData;

  @override
  void initState() {
    super.initState();
    weatherData = fetchWeather(cityname);
  }

  Future<Map<String, dynamic>> fetchWeather(String cityname) async {
    return await wheatherController.getWheatherData(cityname);
  }

  Future<void> searchCity() async {
    if (city.text.isEmpty) {
      cityname = "London"; // Default city if input is empty
    } else {
      cityname = city.text;
    }
    setState(() {
      weatherData = fetchWeather(cityname);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white30,
      appBar: AppBar(
        leading: IconButton(onPressed: () { Navigator.pop(context); }, icon: Icon(Icons.arrow_back)),
        title: Text("Weather App", style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: Colors.white)),
        backgroundColor: Colors.black,
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      height: 60,
                      width: MediaQuery.of(context).size.width - 32,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        color: Colors.deepPurple,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(width: 16),
                          Text("Enter City: ", style: TextStyle(color: Colors.white)),
                          SizedBox(width: 16),
                          Expanded(
                            child: TextField(
                              controller: city,
                              decoration: InputDecoration(
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(5),
                                ),
                                filled: true,
                                fillColor: Colors.white,
                                hintText: "Enter City Name",
                              ),
                            ),
                          ),
                          SizedBox(width: 16),
                          ElevatedButton(onPressed: searchCity, child: Text("Submit"))
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              FutureBuilder<Map<String, dynamic>>(
                future: weatherData,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return CircularProgressIndicator();
                  } else if (snapshot.hasError) {
                    return Text("Error: ${snapshot.error}");
                  } else if (!snapshot.hasData || snapshot.data == null) {
                    return Text("No data found.");
                  } else {
                    final data = snapshot.data!;
                    return Column(
                      children: [
                        Container(
                          margin: EdgeInsets.all(8),
                          padding: EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.white54,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            "City: ${data['name']} \nTemperature: ${((data['main']['temp'] - 32) * 5 / 9).toStringAsFixed(2)}°C\nFeels Like: ${((data["main"]["feels_like"] - 32) * 5 / 9).toStringAsFixed(2)}°C",
                            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ],
                    );
                  }
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
