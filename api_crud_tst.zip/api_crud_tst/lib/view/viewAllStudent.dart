import 'package:flutter/material.dart';
import 'package:api_crud_tst/model/Student.dart';
import "package:api_crud_tst/controller/studentController.dart";

class ViewAllStudent extends StatefulWidget{
  @override
  _ViewAllStudentState createState() => _ViewAllStudentState();
  
}
class _ViewAllStudentState extends State<ViewAllStudent>{

  List<Student> students = [];
  @override
  void initState(){
    super.initState();
    fetchRecords();
  }


  Future<void> fetchRecords() async{
    List<Student> fetchStudent = await StudentController.getAllStudents();
    setState(() {
      students = fetchStudent;
    });
  }

  Future<void> deleteRecord(int id) async{
    await StudentController.deleteRecord(id);
    await fetchRecords();
  }
  @override
  Widget build(BuildContext){
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(onPressed: (){
          Navigator.pop(context);
        }, icon: Icon(Icons.arrow_back)),
        title:Text("Student Management System",style: TextStyle(fontSize: 20, fontFamily: 'Roboto', fontWeight: FontWeight.bold, color:Colors.amberAccent),),
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            children: [
              Container(
                margin: EdgeInsets.all(8),
                height: 60,
                width: double.infinity,
                child: Text("All Students Details :",style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.black),),

              ),
              
              ListView.builder(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemCount: students.length,
                itemBuilder: (context, index){
                  final stu = students[index];
                  return Card(
                    margin: EdgeInsets.all(8),
                    child: ListTile(
                      title: Text("${stu.firstname} ${stu.lastname}"),
                      subtitle: Text("${stu.email}\nCountry : ${stu.country}"),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(onPressed: (){}, icon: Icon(Icons.edit, color: Colors.blue,)),
                          IconButton(onPressed: () async{ await deleteRecord(stu.id!);}, icon: Icon(Icons.delete, color: Colors.red,)),
                        ],
                      ),
                    ),
                  );
                }
              )
            ],
          ),
          
        ),
      ),
    );
  }
}