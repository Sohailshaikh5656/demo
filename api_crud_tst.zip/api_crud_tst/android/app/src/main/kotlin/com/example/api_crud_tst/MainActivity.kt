package com.example.api_crud_tst

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
