package com.example.prachi_b_59

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
