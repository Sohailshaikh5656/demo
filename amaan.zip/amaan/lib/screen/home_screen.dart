import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:  Colors.grey,
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.lightGreen,
        title: Text("Home Screen",
        style: TextStyle(
            fontSize: 15,
          color: Colors.black,
          fontWeight: FontWeight.bold
        ),
        ),
      ) ,
    body: Center(
      child: Column (
       children:[
         SizedBox(height: 30,),
        Container(
          height: 100,
          width: 300,
          color: Colors.pink,
        ),
        SizedBox(height: 30,),
         Container(
           height: 100,
           width: 300,
           color: Colors.green,
         ),
         SizedBox(height: 30,),
         Container(
           height: 100,
           width: 300,
           color: Colors.yellow,
         ),
         SizedBox(height: 30,),
         Row(
           mainAxisAlignment: MainAxisAlignment.center,
           children: [
             Container(
               height: 100,
               width: 100,
               color: Colors.orange,
             ),
             SizedBox(width: 30,),
             Container(
               height: 100,
               width: 100,
               color: Colors.white,
             ),
             SizedBox(width: 30,),
             Container(
               height: 100,
               width: 100,
               color: Colors.greenAccent,
             ),
             SizedBox(width: 30,),
           ],

         ),

      ],
      ),
    ),
    );
  }
}
