import 'package:flutter/material.dart';
import 'package:prachi_b_59/screen/home_screen.dart';

class login extends StatelessWidget{
  const login({super.key});


  
  @override
  Widget build(BuildContext context){
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Image.asset("assets/image/pk.jpg",
              height: 300,
              ),
              SizedBox(height: 30,),
              Text("Login here",
              style: TextStyle(
                color: Colors.purple[200],
                fontSize: 35,
                fontWeight: FontWeight.w700,
              ),
              ),
              SizedBox(height: 30,),

              Padding(
                padding: EdgeInsets.all(30),
                child:Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("UserName",style: TextStyle(
                      color: Colors.black,
                      fontSize: 12),),

          TextFormField(
                  decoration: InputDecoration(
                    //prefixIcon: Icon(Icons.person,color: Colors.red,),
                    suffixIcon:  Icon(Icons.person,color: Colors.black,),
                    hintText: "UserName",
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(15),
                    )
                  ),
                ),
                SizedBox(height: 30,),
                Text("Password",style: TextStyle(
                    color: Colors.black,fontSize: 12),),

                  TextFormField(
                    obscureText: true,
              decoration: InputDecoration(
              hintText: "Password",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
              ),
                  ),
                    //Icon(Icons.person,color: Colors.red,size: 40,),
                    SizedBox(height: 30,),

                    SizedBox(
                      height: 60,
                      width: 2000,
                      child:  ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.purple[200],
                        ),
                        onPressed: () {
                          print('helloo');
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => HomeScreen()));
                        },
                        child: Text('login',
                            style: TextStyle(
                                color: Colors.black,fontSize: 12
                            ),
                        ),
                    ),
                    ),
                    SizedBox(height: 30,),
                    TextButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => HomeScreen()));
                      },
                      child: Text('login',
                        style: TextStyle(
                            color: Colors.black,fontSize: 12
                        ),
                      ),
                    ),
                  ],
              ),

          )
          ],
        ),
      ),
      ),
    );
  }
}