import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor : Colors. teal[50],
        appBar: AppBar(
          centerTitle: true,
          backgroundColor: Colors.pink[200],
          title: Text("Home Screen",
          style: TextStyle(
            fontSize: 15,
            color: Colors.black,
            fontWeight: FontWeight.bold
          ),
          ),
        ),
      body: Center(
      child: Column(
        children: [
          SizedBox(height: 30,),
          Container(
            height: 100,
            width: 300,
            color: Colors.purple[200],
          ),
          SizedBox(height: 30,),
          Container(
            height: 100,
            width: 300,
            color: Colors.purple[400],
          ),
          SizedBox(height: 30,),
          Container(
            height: 100,
            width: 300,
            color: Colors.purple[600],
          ),
          SizedBox(height: 30,),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                height: 100,
                width: 100,
                color: Colors.brown[200],
              ),
              SizedBox(width: 30,),
              Container(
                height: 100,
                width: 100,
                color: Colors.brown[400],
              ),
              SizedBox(width: 30,),
              Container(
                height: 100,
                width: 100,
                color: Colors.brown[600],
              ),
              SizedBox(width: 30,),
            ],
          ),
        ],
      ),
      ),
    );

  }
}
