import 'package:flutter/material.dart';
import 'package:princy_b_30/screen/Design.dart';
class Design extends StatelessWidget {
  const Design({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue,
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.green,
        title: Text("Flutter Page ",style:TextStyle( fontSize: 15,
            color: Colors.black,
            fontWeight: FontWeight.bold
        ),
        ),

      ),


      body: Center(
      child: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 30,),
            Container(
              height: 500,
              width: 400,
              color : Colors.lightGreen,
              child: Column(

                children: [
                  SizedBox(height: 10,),
                  Container(
                    height: 70,
                    width: 350,
                    color: Colors.cyan,
                    child: Center(child: Text('Container 1')),
                  ),
                  SizedBox(height: 20,),
                  Container(
                    height: 70,
                    width: 350,
                    color: Colors.cyan,
                    child: Center(child: Text('Container 2')),
                  ),
                  SizedBox(height: 20,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children:[
                    SizedBox(height: 20,width: 25,),
                    Container(
                      height: 140,
                      width: 50,
                      color: Colors.cyan,
                      child: Center(child: Text('Container 3')),

                    ),
                    SizedBox(width: 30,),
                    Container(
                      height: 140,
                      width: 50,
                      color: Colors.cyan,
                      child: Center(child: Text('Container 4')),
                    ),

                SizedBox(height:100,width: 0),
                Expanded(
                  child: Container(
                      height: 140,
                      width: 100,

                      margin: EdgeInsets.only(left: 15),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [

                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [


                              Container(
                                margin: EdgeInsets.only(top: 15),
                                height: 50,
                                color: Colors.orange,
                                width: 50,
                              ),
                              Container(
                                margin: EdgeInsets.only(top: 15),
                                height: 50,
                                color: Colors.orange,
                                width: 50,
                              ),
                              Container(
                                margin: EdgeInsets.only(top: 15),
                                height: 50,
                                color: Colors.orange,
                                width: 50,
                              ),
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Container(
                                margin: EdgeInsets.only(bottom: 15),
                                height: 50,
                                color: Colors.orange,
                                width: 180,
                              )

                            ],
                          ),
                        ],
                      ),
                  ),
                ),

                  ],
                ),
                ],
              )
            ),

          ],
        ),
      ),
      ),

    );
  }
}
