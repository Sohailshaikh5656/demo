<?php 
    
    function dbConection(){
        $localhost = "localhost";
        $username = "root";
        $password = "";
        $dbName = "student";

        $conn = new mysqli($localhost, $username, $password, $dbName);
        return $conn;
    }
?>