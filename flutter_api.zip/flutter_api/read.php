<?php
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
    header("Access-Control-Allow-Headers: Content-Type, Authorization");
    header("Content-Type: application/json; charset=UTF-8");

    include("dbConn.php");

    $conn = dbConection();
    if($conn->connect_error){
        die("Connection Failed: " . $conn->connect_error);
    }

    $sql = "SELECT * FROM students";
    $result = $conn->query($sql);
    $students = [];

    if($result->num_rows > 0){
        while($row = $result->fetch_assoc()){
            $students[] = $row;
        }
        echo json_encode($students);
    } else {
        echo json_encode([]);
    }
?>
