<?php 
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Content-Type: application/json");

include("dbConn.php");
$conn = dbConection();

if($conn->connect_error){
    die("Connection failed: " . $conn->connect_error);
}

// Check if POST variables are set
if (isset($_POST['firstname']) && isset($_POST['lastname']) && isset($_POST['email']) && isset($_POST['password']) && isset($_POST['country'])) {
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $country = $_POST['country'];

    $sql = "INSERT INTO students(firstname, lastname, email, password, country) VALUES('$firstname','$lastname','$email','$password','$country')";

    if($conn->query($sql) === TRUE) {
        echo json_encode(["success" => true, "message" => "New Record Inserted successfully!"]);
    } else {
        echo json_encode(["success" => false, "message" => "Error: " . $conn->error]);
    }

    $conn->close();
} else {
    echo json_encode(["success" => false, "message" => "Missing required fields."]);
}
?>