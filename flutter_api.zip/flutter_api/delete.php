<?php 
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Content-Type: application/json");

include("dbConn.php");
$conn = dbConection();

if($conn->connect_error){
    die("Connection failed: " . $conn->connect_error);
}

// Check if POST variables are set
if (isset($_POST['id'])){
    $id = (int) $_POST['id'];
   

    $sql = "DELETE FROM students where id = $id";

    if($conn->query($sql) === TRUE) {
        echo json_encode(["success" => true, "message" => "Record Deleted successfully!"]);
    } else {
        echo json_encode(["success" => false, "message" => "Error: " . $conn->error]);
    }

    $conn->close();
} else {
    echo json_encode(["success" => false, "message" => "Missing required fields."]);
}
?>