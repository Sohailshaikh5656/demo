import 'package:flutter/material.dart';
import 'package:princy_b_30/screen/home_screen.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Image.asset("assets/images/pk.jpg",
                height: 300,
              ),
              SizedBox(height: 30,),
              Text("Login Here",
              style: TextStyle(
                color: Colors.blueGrey,
                fontSize: 35,
                fontWeight: FontWeight.bold,
              ),
              ),
              SizedBox(height: 30,),
            Padding(
                padding: const EdgeInsets.all(30),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("UserName",style: TextStyle(
                      color: Colors.black, fontSize: 12),),
                TextFormField(
                  decoration: InputDecoration(
                    //prefixIcon: Icon(Icons.person,color: Colors.red[400]),
                    suffixIcon: Icon(Icons.person,color: Colors.red[400],),
                    hintText: "Enter UserName or Email Id",
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(15),
                    )
                  ),
                ),
                SizedBox(height: 30,),
                Text("Password",style: TextStyle(color: Colors.black,fontSize: 12),),
                 TextFormField(
                   obscureText: true,
                  decoration: InputDecoration(
                    hintText: "Password",
                      border: OutlineInputBorder(
                         borderRadius: BorderRadius.circular(15),
                  )
                ),
              ),
                    SizedBox(height: 30,),
                    SizedBox(
                      height: 60,
                      width: 2000,

                    child :ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red
                      ),
                        onPressed: (){
                        print("Hello");
                        Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => HomeScreen()));
                        },
                        child:Text("Login",
                          style: TextStyle(
                              color:Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 30),
                        ),
                    ),
                    ),
                    TextButton(onPressed: () {
                      Navigator.push(context,
                          MaterialPageRoute(
                              builder: (context) => HomeScreen()));
                    },
                      child:Text("Login",
                        style: TextStyle(
                            color:Colors.black,
                            fontWeight: FontWeight.bold,
                            fontSize: 30),
                      ),
                    ),
              ],
              ),
            )
          ],
          ),
        ),
      ),
    );
  }
}
