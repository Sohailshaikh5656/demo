import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:princy_b_30/screen/home_screen.dart';

class LoginScreen extends StatelessWidget {
  LoginScreen({super.key});

  TextEditingController username = TextEditingController();
  TextEditingController password = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Image.asset("assets/images/pk.jpg",
                height: 300,
              ),
              SizedBox(height: 30,),
              Text("Login Here",
              style: TextStyle(
                color: Colors.blueGrey,
                fontSize: 35,
                fontWeight: FontWeight.bold,
              ),
              ),
              SizedBox(height: 30,),
            Padding(
                padding: const EdgeInsets.all(30),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("UserName",style: TextStyle(
                      color: Colors.black, fontSize: 12),),
                TextFormField(
                  controller: username,
                  decoration: InputDecoration(
                    //prefixIcon: Icon(Icons.person,color: Colors.red[400]),
                    suffixIcon: Icon(Icons.person,color: Colors.red[400],),
                    hintText: "Enter UserName or Email Id",
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(15),
                    )
                  ),
                ),
                SizedBox(height: 30,),
                Text("Password",style: TextStyle(color: Colors.black,fontSize: 12),),
                 TextFormField(
                   controller: password,
                   obscureText: true,
                  decoration: InputDecoration(
                    hintText: "Enter Password",
                      border: OutlineInputBorder(
                         borderRadius: BorderRadius.circular(15),
                  )
                ),
              ),
                    SizedBox(height: 30,),
                    SizedBox(
                      height: 60,
                      width: 2000,

                    child :ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red
                      ),
                        onPressed: (){
                        if(username.text.isEmpty){
                          toast("Please Enter Username ");
                        }
                        else if(password.text.isEmpty){
                          toast("Please Enter Password");
                        }
                        else{
                          Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => HomeScreen()));
                        }
                        print("Hello");
                        },
                        child:Text("Login",
                          style: TextStyle(
                              color:Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 30),
                        ),
                    ),
                    ),
                    TextButton(onPressed: () {
                      Navigator.push(context,
                          MaterialPageRoute(
                              builder: (context) => HomeScreen()));
                    },
                      child:Text("Login",
                        style: TextStyle(
                            color:Colors.black,
                            fontWeight: FontWeight.bold,
                            fontSize: 30),
                      ),
                    ),
              ],
              ),
            )
          ],
          ),
        ),
      ),
    );
  }

  void toast(String msg){
    Fluttertoast.showToast(
        msg: "${msg}",
        webShowClose: true,
        webBgColor: "#00b09b",
        webPosition: "center",

        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.CENTER,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.red,
        textColor: Colors.white,
        fontSize: 16.0
    );
  }
}
