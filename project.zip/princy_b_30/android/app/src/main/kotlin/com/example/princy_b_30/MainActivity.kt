package com.example.princy_b_30

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
