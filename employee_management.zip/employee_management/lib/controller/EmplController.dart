import 'dart:convert';
import 'package:http/http.dart' as http;
import '../model/admin_login.dart';

class EmplController {
  // Admin login check
  Future<bool> checkAdminCredentials(String email, String password) async {
    try {
      String uri = "http://localhost/Flutter_Employee_Management/adminLogin.php"; // Update with your API endpoint

      // Create an AdminLogin object
      var adminLogin = AdminLogin(email: email, password: password);

      // Prepare request body using the model
      var bodyData = jsonEncode(adminLogin.toJson());

      var res = await http.post(
        Uri.parse(uri),
        headers: {"Content-Type": "application/json"},
        body: bodyData,
      );

      if (res.statusCode == 200) {
        var response = jsonDecode(res.body);
        print("Response from server: ${response}"); // Debugging line

        // Assuming the response has a key "status" for successful login
        return response['status'] == "success"; // Adjust based on your server response structure
      } else {
        print("Failed to login with status: ${res.statusCode}");
        return false;
      }
    } catch (e) {
      print("Error during login: $e");
      return false;
    }
  }
}
