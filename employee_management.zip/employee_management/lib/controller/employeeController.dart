import 'dart:convert';
import 'package:http/http.dart' as http;
import '../model/addNewEmp.dart';

class EmplController {
  Future<void> insertEmployee(Employee emp) async {
    try {
      String uri = "http://localhost/Flutter_Employee_Management/insert.php";
      String bodyData = jsonEncode(emp.toJson());

      print("Request Body: $bodyData"); // Debug the request body

      var res = await http.post(
        Uri.parse(uri),
        headers: {"Content-Type": "application/json"},
        body: bodyData,
      );

      print("Response Status: ${res.statusCode}");
      print("Response Body: ${res.body}");

      if (res.statusCode == 200) {
        var response = jsonDecode(res.body);
        if (response["success"] == "true") {
          print("Record Inserted successfully !");
        } else {
          print("Failed to Insert Record : ${response['message']}");
        }
      } else {
        print("Request failed with Status : ${res.statusCode}");
      }
    } catch (e) {
      print("An error occurred: $e");
    }
  }
  Future<List<Employee>> fetchEmployees() async {
    try {
      String uri = "http://localhost/Flutter_Employee_Management/allEmp.php"; // For Android emulator

      var res = await http.get(Uri.parse(uri));
      if (res.statusCode == 200) {
        // Ensure the response is valid JSON
        List<dynamic> body = jsonDecode(res.body);
        if (body is List) {
          return body.map((item) => Employee.fromJson(item)).toList();
        } else {
          print("Unexpected response format: ${res.body}");
          throw Exception("Unexpected response format");
        }
      } else {
        print("Server returned error code: ${res.statusCode}");
        throw Exception("Failed to load employees");
      }
    } catch (e) {
      print("Error fetching employees: $e");
      return [];
    }
  }


  Future<bool> deleteEmployee(int id) async {
    try {
      String uri = "http://localhost/Flutter_Employee_Management/delete.php";
      var res = await http.post(
        Uri.parse(uri),
        body: {"id": id.toString()},
      );

      if (res.statusCode == 200) {
        var response = jsonDecode(res.body);
        return response['success'] == "true";
      } else {
        print("Failed to delete employee: ${res.statusCode}");
        return false;
      }
    } catch (e) {
      print("Error deleting employee: $e");
      return false;
    }
  }

  Future<bool> updateEmployee(Employee emp) async {
    try {
      String uri = "http://localhost/Flutter_Employee_Management/update.php";
      var res = await http.post(
        Uri.parse(uri),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode(emp.toJson()),
      );

      if (res.statusCode == 200) {
        var response = jsonDecode(res.body);
        return response["success"] == "true";
      } else {
        throw Exception("Failed to update employee.");
      }
    } catch (e) {
      print("An error occurred: $e");
      return false;
    }
  }
}
