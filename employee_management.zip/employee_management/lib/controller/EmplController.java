import 'dart:convert';
import 'package:http/http.dart' as http;
import '../model/admin_login.dart';

class EmplController {
  // Admin login check
  Future<bool> checkAdminCredentials(String email, String password) async {
    try {
      String uri = "http://localhost/Flutter_Employee_Management/adminLogin.php"; // Update with your API endpoint

      // Prepare request body
      var bodyData = jsonEncode({
        'email': email,
        'password': password,
      });

      var res = await http.post(
        Uri.parse(uri),
        headers: {"Content-Type": "application/json"},
        body: bodyData,
      );

      if (res.statusCode == 200) {
        var response = jsonDecode(res.body);
        // Assuming the response has a key "success" for successful login
        return response['success'] == "true";
      } else {
        print("Failed to login with status: ${res.statusCode}");
        return false;
      }
    } catch (e) {
      print("Error during login: $e");
      return false;
    }
  }
}
