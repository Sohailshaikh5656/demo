import 'package:flutter/material.dart';
import 'package:employee_management/controller/employeeController.dart';
import 'package:employee_management/model/addNewEmp.dart';
import 'EditEmployee.dart'; // Import the EditEmployee screen

class ViewEmployees extends StatefulWidget {
  @override
  _ViewEmployeesState createState() => _ViewEmployeesState();
}

class _ViewEmployeesState extends State<ViewEmployees> {
  final EmplController empController = EmplController();
  Future<List<Employee>>? futureEmployees;

  @override
  void initState() {
    super.initState();
    futureEmployees = empController.fetchEmployees();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Employees'),
      ),
      body: FutureBuilder<List<Employee>>(
        future: futureEmployees,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('No employees found.'));
          }

          List<Employee> employees = snapshot.data!;

          return ListView.builder(
            itemCount: employees.length,
            itemBuilder: (context, index) {
              Employee emp = employees[index];
              return Card(
                margin: EdgeInsets.all(10),
                child: ListTile(
                  title: Text(emp.name),
                  subtitle: Text('${emp.position} in ${emp.department}'),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: Icon(Icons.edit, color: Colors.blue),
                        onPressed: () async {
                          final result = await Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => EditEmployee(employee: emp),
                            ),
                          );
                          if (result == true) {
                            setState(() {
                              futureEmployees = empController.fetchEmployees(); // Refresh the employee list
                            });
                          }
                        },
                      ),
                      IconButton(
                        icon: Icon(Icons.delete, color: Colors.red),
                        onPressed: () async {
                          bool isDeleted = await _deleteEmployee(emp);
                          if (isDeleted) {
                            setState(() {
                              futureEmployees = empController.fetchEmployees(); // Refresh the employee list
                            });
                          } else {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text('Failed to delete employee')),
                            );
                          }
                        },
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  Future<bool> _deleteEmployee(Employee emp) async {
    bool isDeleted = await empController.deleteEmployee(emp.id); // Call the delete method
    if (isDeleted) {
      print("Deleted employee: ${emp.name}");
    } else {
      print("Failed to delete employee: ${emp.name}");
    }
    return isDeleted; // Return the deletion status
  }
}
