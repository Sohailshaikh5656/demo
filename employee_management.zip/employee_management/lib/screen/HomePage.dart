import 'package:employee_management/screen/AddEmp.dart';
import 'package:employee_management/screen/allEmployee.dart';
import 'package:flutter/material.dart';

class homepage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<homepage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('CRUD Operations'),
        backgroundColor: Colors.purple, // Set the AppBar color
      ),
      backgroundColor: Color(0xFF252525),
      body: SingleChildScrollView( // Enable scrolling
        child: Container(
          margin: EdgeInsets.all(16.0), // Apply margin for the body
          child: Center(
            child: Container(
              height: 700,
              width: 400,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.purple,
              ),
              child: Center(
                child: Column(
                  children: [
                    SizedBox(height: 20),
                    Container(
                      height: 60,
                      width: 400,
                      child: Center(
                        child: Text(
                          'Crud Operations',
                          style: TextStyle(
                            fontSize: 36,
                            fontFamily: 'Roboto',
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 10),
                    Container(
                      height: 300,
                      width: 300,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Image.network(
                          'lib/images/emp.webp',
                          fit: BoxFit.cover,
                        ),
                      ),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.amber,
                      ),
                    ),
                    SizedBox(height: 30),
                    Container(
                      height: 60,
                      width: 350,
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => AddNewEmployee()),
                          );
                        },
                        child: Text(
                          'Add New Employee',
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 26),
                        ),
                      ),
                    ),
                    SizedBox(height: 20),
                    Container(
                      height: 60,
                      width: 350,
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => ViewEmployees()),
                          );
                        },
                        child: Text(
                          'Operation of Employee',
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 26),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
