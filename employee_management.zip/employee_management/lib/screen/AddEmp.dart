import 'package:employee_management/controller/employeeController.dart';
import 'package:employee_management/model/addNewEmp.dart';
import 'package:flutter/material.dart';

class AddNewEmployee extends StatefulWidget {
  @override
  _AddNewEmployeeState createState() => _AddNewEmployeeState();
}

class _AddNewEmployeeState extends State<AddNewEmployee> {
  final TextEditingController name = TextEditingController();
  final TextEditingController department = TextEditingController();
  final TextEditingController position = TextEditingController();
  final TextEditingController salary = TextEditingController();
  final TextEditingController contact = TextEditingController();
  final EmplController emp = EmplController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add New Employee'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context); // Navigate back to the previous screen
          },
        ),
        backgroundColor: Colors.purple, // You can set the AppBar color here
      ),
      backgroundColor: Color(0xFF252525),
      body: SingleChildScrollView(
        child: Center(
          child: Container(
            height: 650,
            width: 350,
            decoration: BoxDecoration(
              color: Colors.purple,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Center(
              child: Column(
                children: [
                  SizedBox(height: 10),
                  Container(
                    height: 60,
                    width: 300,
                    child: Center(
                      child: Text(
                        'Add New Employee',
                        style: TextStyle(
                          fontSize: 26,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Roboto',
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 5),
                  Container(
                    height: 100,
                    width: 100,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(50),
                      child: Image.asset(
                        'lib/images/emp.webp',
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  SizedBox(height: 20),
                  // Employee details fields
                  Container(
                    height: 50,
                    width: 300,
                    child: TextFormField(
                      controller: name,
                      decoration: InputDecoration(
                        fillColor: Colors.white54,
                        filled: true,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        hintText: "Enter the name of Employee",
                      ),
                    ),
                  ),
                  SizedBox(height: 20),
                  Container(
                    height: 50,
                    width: 300,
                    child: TextFormField(
                      controller: department,
                      decoration: InputDecoration(
                        fillColor: Colors.white54,
                        filled: true,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        hintText: "Department",
                      ),
                    ),
                  ),
                  SizedBox(height: 20),
                  Container(
                    height: 50,
                    width: 300,
                    child: TextFormField(
                      controller: position,
                      decoration: InputDecoration(
                        fillColor: Colors.white54,
                        filled: true,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        hintText: "Position",
                      ),
                    ),
                  ),
                  SizedBox(height: 20),
                  Container(
                    height: 50,
                    width: 300,
                    child: TextFormField(
                      controller: salary,
                      decoration: InputDecoration(
                        fillColor: Colors.white54,
                        filled: true,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        hintText: "Salary",
                      ),
                    ),
                  ),
                  SizedBox(height: 20),
                  Container(
                    height: 50,
                    width: 300,
                    child: TextFormField(
                      controller: contact,
                      decoration: InputDecoration(
                        fillColor: Colors.white54,
                        filled: true,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        hintText: "Contact",
                      ),
                    ),
                  ),
                  SizedBox(height: 20),
                  Container(
                    height: 60,
                    width: 300,
                    child: ElevatedButton(
                      onPressed: () async {
                        EmplController empController = EmplController();
                        Employee emp = Employee(
                          id: 0, // Set a default value for id
                          name: name.text,
                          department: department.text,
                          position: position.text,
                          salary: salary.text,
                          contact: contact.text,
                        );
                        await empController.insertEmployee(emp);
                        name.clear();
                        department.clear();
                        position.clear();
                        salary.clear();
                        contact.clear();
                      },
                      child: Text(
                        'ADD Employee',
                        style: TextStyle(
                          color: Colors.purple,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Roboto',
                          fontSize: 20,
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
