import 'package:flutter/material.dart';
import 'package:employee_management/controller/employeeController.dart';
import 'package:employee_management/model/addNewEmp.dart';

class EditEmployee extends StatefulWidget {
  final Employee employee;

  EditEmployee({required this.employee});

  @override
  _EditEmployeeState createState() => _EditEmployeeState();
}

class _EditEmployeeState extends State<EditEmployee> {
  final EmplController empController = EmplController();
  late TextEditingController nameController;
  late TextEditingController departmentController;
  late TextEditingController positionController;
  late TextEditingController salaryController;
  late TextEditingController contactController;

  @override
  void initState() {
    super.initState();
    nameController = TextEditingController(text: widget.employee.name);
    departmentController = TextEditingController(text: widget.employee.department);
    positionController = TextEditingController(text: widget.employee.position);
    salaryController = TextEditingController(text: widget.employee.salary);
    contactController = TextEditingController(text: widget.employee.contact);
  }

  @override
  void dispose() {
    nameController.dispose();
    departmentController.dispose();
    positionController.dispose();
    salaryController.dispose();
    contactController.dispose();
    super.dispose();
  }

  void _updateEmployee() async {
    Employee updatedEmployee = Employee(
      id: widget.employee.id,
      name: nameController.text,
      department: departmentController.text,
      position: positionController.text,
      salary: salaryController.text,
      contact: contactController.text,
    );

    bool isUpdated = await empController.updateEmployee(updatedEmployee);
    if (isUpdated) {
      Navigator.pop(context, true); // Return true to indicate success
    } else {
      // Handle update failure (e.g., show a snackbar)
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to update employee.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Edit Employee'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: nameController,
              decoration: InputDecoration(labelText: 'Name'),
            ),
            TextField(
              controller: departmentController,
              decoration: InputDecoration(labelText: 'Department'),
            ),
            TextField(
              controller: positionController,
              decoration: InputDecoration(labelText: 'Position'),
            ),
            TextField(
              controller: salaryController,
              decoration: InputDecoration(labelText: 'Salary'),
            ),
            TextField(
              controller: contactController,
              decoration: InputDecoration(labelText: 'Contact'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _updateEmployee,
              child: Text('Update Employee'),
            ),
          ],
        ),
      ),
    );
  }
}
