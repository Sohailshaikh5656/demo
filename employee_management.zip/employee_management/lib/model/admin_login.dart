class AdminLogin {
  final String email;
  final String password;

  AdminLogin({required this.email, required this.password});

  // Convert JSON to AdminLogin object
  factory AdminLogin.fromJson(Map<String, dynamic> json) {
    return AdminLogin(
      email: json['email'],
      password: json['password'],
    );
  }

  // Convert AdminLogin object to JSON
  Map<String, dynamic> toJson() {
    return {
      'email': email,
      'password': password,
    };
  }
}
