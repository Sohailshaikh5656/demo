class Employee {
  int id; // Ensure this is non-nullable
  String name;
  String department;
  String position;
  String salary; // Assuming this is a String; if it's double, change it accordingly
  String contact;

  Employee({
    required this.id,
    required this.name,
    required this.department,
    required this.position,
    required this.salary,
    required this.contact,
  });

  factory Employee.fromJson(Map<String, dynamic> json) {
    return Employee(
      id: int.parse(json['id'].toString()),  // Convert id to an int
      name: json['name'],
      department: json['department'],
      position: json['position'],
      salary: json['salary'],
      contact: json['contact'],
    );
  }
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'department': department,
      'position': position,
      'salary': salary,
      'contact': contact,
    };
  }
}
